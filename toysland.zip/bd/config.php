<?php 

define('DB_SERVER', 'localhost');
define('DB_NAME', 'id19410025_aw2022');
define('DB_USER', 'id19410025_eden');
define('DB_PASS', '1oav~1wf50@gAY(X');

 ?>